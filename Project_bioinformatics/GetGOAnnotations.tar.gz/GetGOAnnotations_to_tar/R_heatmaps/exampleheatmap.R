
# Load necessary libraries:
library(MASS)
library(gplots)
library(RColorBrewer)

# Read in data, and assign names and data to appropriate columns:
exdata <- read.csv("EXAMPLEDATA.csv")
GOnames <- exdata[,1:1]
data <- exdata[,2:6] 

# Make a data frame, order it based on the values in the first column, and convert it to a data matrix:
frame <- data.frame(data,row.names=GOnames)
ordered <- frame[order(frame$All_Aster, decreasing=TRUE),]
data_matrix <- data.matrix(ordered)

# Build a custom color palette:
Fullpalette <- colorRampPalette(c( "#570857","#62119C", "#3337EE","#1572D5","#00AF9A","#00D133","#42E100","#C8DD00","#E5A800","#EF6901","#F82807","#B00F0F"))

# Make a heatmap out of that palette:
data_heatmap <- heatmap.2(data_matrix, col=Fullpalette, key=TRUE, breaks=c(0,0.117456013,0.230561985,0.243185383,0.313164682,0.391461621,0.411881592,0.415575306,0.470171862,0.624057786,0.664333149,0.746697416,0.806111067,0.907768399,0.981927326,1.09330094,1.296760414,1.312672249,1.386120337,1.492926623,1.544940069,1.557366774,1.627452632,1.708613929,1.789808109,1.818247605,1.957087763,1.95899227,2.399780797,2.45864764,2.476049218,2.538123616,2.591189121,2.720636987,2.793829837,2.923500682,2.99220273,3.34082841,3.513625085,3.794743712,5.455846129,6.563635788,7.865832665,8.113422777,9.589461506,10.29005525,11.60115053,12.31617647,14.88970588), dendrogram="none", trace="none", cexCol=1, margins=c(5,12), density.info="histogram", Rowv=FALSE, Colv=FALSE)





# Save the heatmap directly to a PDF:
pdf(file="GOheatmap.pdf")
data_heatmap <- heatmap.2(data_matrix, col=Fullpalette, key=TRUE, breaks=c(0,0.117456013,0.230561985,0.243185383,0.313164682,0.391461621,0.411881592,0.415575306,0.470171862,0.624057786,0.664333149,0.746697416,0.806111067,0.907768399,0.981927326,1.09330094,1.296760414,1.312672249,1.386120337,1.492926623,1.544940069,1.557366774,1.627452632,1.708613929,1.789808109,1.818247605,1.957087763,1.95899227,2.399780797,2.45864764,2.476049218,2.538123616,2.591189121,2.720636987,2.793829837,2.923500682,2.99220273,3.34082841,3.513625085,3.794743712,5.455846129,6.563635788,7.865832665,8.113422777,9.589461506,10.29005525,11.60115053,12.31617647,14.88970588), dendrogram="none", trace="none", cexCol=1, margins=c(5,12), density.info="histogram", Rowv=FALSE, Colv=FALSE)
dev.off()