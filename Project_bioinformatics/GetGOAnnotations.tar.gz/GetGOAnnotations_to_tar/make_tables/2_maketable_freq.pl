#############
#
#	Emily Sessa, Aug 2012
#	Barker lab, UA EEB
#
#	Idea: to take output from encompassing and duplicated gene pipelines and get frequency data for GO categories
#		This will then be used as input for R to make the heatmaps
#	On command line: perl 	maketable_freq.pl	compare_annotations or WGD_file
#
#############

$file1 = $ARGV[0];

open (IN1, $file1);

$length1 = 0;
	$cellorgbio = 0;
	$cellwall = 0;
	$chloroplast = 0;
	$cytosol = 0;
	$devproc = 0;
	$DNAbind = 0;
	$DNAmeta = 0;
	$electrans = 0;
	$ER = 0;
	$extracell = 0;
	$Golgi = 0;
	$hydrolase = 0;
	$kinase = 0;
	$mito = 0;
	$nucacbind = 0;
	$nuctibind = 0;
	$nucleus = 0;
	$otherbind = 0;
	$otherbio = 0;
	$othercellcom = 0;
	$othercellproc = 0;
	$othercyto = 0;
	$otherenzyme = 0;
	$otherintra = 0;
	$othermem = 0;
	$othermetab = 0;
	$othermolec = 0;
	$plasma = 0;
	$plastid = 0;
	$protbind = 0;
	$protmet = 0;
	$recepbind = 0;
	$respabio = 0;
	$respstress = 0;
	$ribosome = 0;
	$signal = 0;
	$strucmol = 0;
	$transfac = 0;
	$transferase = 0;
	$transport = 0;
	$transporter = 0;
	$unkbiol = 0;
	$unkcell = 0;
	$unkmol = 0;


while (<IN1>) {
	chomp();
	push @array1, $_;
	@array1 = split/\t/;
	$length1 = $length1+1;
	if ($array1[1] =~ m/cell organization and biogenesis/) {$cellorgbio = $cellorgbio+1} 
	if ($array1[1] =~ m/cell wall/) {$cellwall = $cellwall+1} 
	if ($array1[1] =~ m/chloroplast/) {$chloroplast = $chloroplast+1}	
	if ($array1[1] =~ m/cytosol/) {$cytosol = $cytosol+1} 
	if ($array1[1] =~ m/developmental processes/) {$devproc = $devproc+1} 
	if ($array1[1] =~ m/DNA or RNA binding/) {$DNAbind = $DNAbind+1} 
	if ($array1[1] =~ m/DNA or RNA metabolism/) {$DNAmeta = $DNAmeta+1} 
	if ($array1[1] =~ m/electron transport or energy pathways/) {$electrans = $electrans+1} 
	if ($array1[1] =~ m/ER/) {$ER = $ER+1}
	if ($array1[1] =~ m/extracellular/) {$extracell = $extracell+1}
	if ($array1[1] =~ m/Golgi apparatus/) {$Golgi = $Golgi+1}
	if ($array1[1] =~ m/hydrolase activity/) {$hydrolase = $hydrolase+1}
	if ($array1[1] =~ m/kinase activity/) {$kinase = $kinase+1}
	if ($array1[1] =~ m/mitochondria/) {$mito = $mito+1}	
	if ($array1[1] =~ m/nucleic acid binding/) {$nucacbind = $nucacbind+1}
	if ($array1[1] =~ m/nucleotide binding/) {$nuctibind = $nuctibind+1}
	if ($array1[1] =~ m/nucleus/) {$nucleus = $nucleus+1}
	if ($array1[1] =~ m/other binding/) {$otherbind = $otherbind+1}
	if ($array1[1] =~ m/other biological processes/) {$otherbio = $otherbio+1}
	if ($array1[1] =~ m/other cellular components/) {$othercellcom = $othercellcom+1}
	if ($array1[1] =~ m/other cellular processes/) {$othercellproc = $othercellproc+1}
	if ($array1[1] =~ m/other cytoplasmic components/) {$othercyto = $othercyto+1}
	if ($array1[1] =~ m/other enzyme activity/) {$otherenzyme = $otherenzyme+1}
	if ($array1[1] =~ m/other intracellular components/) {$otherintra = $otherintra+1}
	if ($array1[1] =~ m/other membranes/) {$othermem = $othermem+1}
	if ($array1[1] =~ m/other metabolic processes/) {$othermetab = $othermetab+1}
	if ($array1[1] =~ m/other molecular functions/) {$othermolec = $othermolec+1}
	if ($array1[1] =~ m/plasma membrane/) {$plasma = $plasma+1}
	if ($array1[1] =~ m/plastid/) {$plastid = $plastid+1}
	if ($array1[1] =~ m/protein binding/) {$protbind = $protbind+1}
	if ($array1[1] =~ m/protein metabolism/) {$protmet = $protmet+1}
	if ($array1[1] =~ m/receptor binding or activity/) {$recepbind = $recepbind+1}
	if ($array1[1] =~ m/response to abiotic or biotic stimulus/) {$respabio = $respabio+1}
	if ($array1[1] =~ m/response to stress/) {$respstress = $respstress+1}
	if ($array1[1] =~ m/ribosome/) {$ribosome = $ribosome+1}
	if ($array1[1] =~ m/signal transduction/) {$signal = $signal+1}
	if ($array1[1] =~ m/structural molecule activity/) {$strucmol = $strucmol+1}
	if ($array1[1] =~ m/transcription factor activity/) {$transfac = $transfac+1}
	if ($array1[1] =~ m/transferase activity/) {$transferase = $transferase+1}
	if ($array1[1] =~ m/\Atransport\b/) {$transport = $transport+1}
	if ($array1[1] =~ m/transporter activity/) {$transporter = $transporter+1}
	if ($array1[1] =~ m/unknown biological processes/) {$unkbiol = $unkbiol+1}
	if ($array1[1] =~ m/unknown cellular components/) {$unkcell = $unkcell+1}
	if ($array1[1] =~ m/unknown molecular functions/) {$unkmol = $unkmol+1}
}	

	#print "The length of array1 is $length1\n"; 
	#print "The length of mito is $mito\n";
	#print "The length of ER is $ER\n";





open (OUT, ">freqTable_$file1");
print OUT "GO category, $file1\n";

@table = (
	['cell organization and biogenesis', $cellorgbio/$length1*100],
	['cell wall', $cellwall/$length1*100],
	['chloroplast', $chloroplast/$length1*100],	
	['cytosol', $cytosol/$length1*100],
	['developmental processes', $devproc/$length1*100],
	['DNA or RNA binding', $DNAbind/$length1*100],
	['DNA or RNA metabolism', $DNAmeta/$length1*100], 
	['electron transport or energy pathways', $electrans/$length1*100],
	['ER', $ER/$length1*100],
	['extracellular', $extracell/$length1*100],
	['Golgi apparatus', $Golgi/$length1*100],
	['hydrolase activity', $hydrolase/$length1*100],
	['kinase activity', $kinase/$length1*100],
	['mitochondria', $mito/$length1*100],
	['nucleic acid binding', $nucacbind/$length1*100],
	['nucleotide binding', $nuctibind/$length1*100],
	['nucleus', $nucleus/$length1*100],
	['other binding', $otherbind/$length1*100],
	['other biological processes', $otherbio/$length1*100],
	['other cellular components', $othercellcom/$length1*100],
	['other cellular processes', $othercellproc/$length1*100],
	['other cytoplasmic components', $othercyto/$length1*100],
	['other enzyme activity', $otherenzyme/$length1*100],
	['other intracellular components', $otherintra/$length1*100],
	['other membranes', $othermem/$length1*100],
	['other metabolic processes', $othermetab/$length1*100],
	['other molecular functions', $othermolec/$length1*100],
	['plasma membrane', $plasma/$length1*100],
	['plastid', $plastid/$length1*100],
	['protein binding', $protbind/$length1*100],
	['protein metabolism', $protmet/$length1*100],
	['receptor binding or activity', $recepbind/$length1*100],
	['response to abiotic or biotic stimulus', $respabio/$length1*100],
	['response to stress', $respstress/$length1*100],
	['ribosome', $ribosome/$length1*100],
	['signal transduction', $signal/$length1*100],
	['structural molecule activity', $strucmol/$length1*100],
	['transcription factor activity', $transfac/$length1*100],
	['transferase activity', $transferase/$length1*100],
	['transport', $transport/$length1*100],
	['transporter activity', $transporter/$length1*100],
	['unknown biological processes', $unkbiol/$length1*100],
	['unknown cellular components', $unkcell/$length1*100],
	['unknown molecular functions', $unkmol/$length1*100],
	);

for $row (@table) {
	my $join = join(',', @$row),;
	print OUT "$join\n";
	}

close(IN1);
close(OUT);





#my @table = (
#	['a', 'b', 'c'],
#	[1, 2, 3],
#	['gene', 'ks', 'annot'],
#	);

#for my $row (@table) {
#	my $join = join(',', @$row),;
#	print OUT "$join\n";
#	}

#close(OUT);