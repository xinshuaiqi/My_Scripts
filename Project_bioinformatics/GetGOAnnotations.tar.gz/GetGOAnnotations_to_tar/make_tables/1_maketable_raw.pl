#############
#
#	Emily Sessa, Aug 2012
#	Barker lab, UA EEB
#
#	Idea: to take output from encompassing and duplicated gene pipelines and get frequency data for GO categories
#		This will then be used as input for R to make the heatmaps
#	On command line: perl 	maketable_raw.pl	compare_annotations or WGD_file
#
#############

$file1 = $ARGV[0];

open (IN1, $file1);

$length1 = 0;
	$cellorgbio = 0;
	$cellwall = 0;
	$chloroplast = 0;
	$cytosol = 0;
	$devproc = 0;
	$DNAbind = 0;
	$DNAmeta = 0;
	$electrans = 0;
	$ER = 0;
	$extracell = 0;
	$Golgi = 0;
	$hydrolase = 0;
	$kinase = 0;
	$mito = 0;
	$nucacbind = 0;
	$nuctibind = 0;
	$nucleus = 0;
	$otherbind = 0;
	$otherbio = 0;
	$othercellcom = 0;
	$othercellproc = 0;
	$othercyto = 0;
	$otherenzyme = 0;
	$otherintra = 0;
	$othermem = 0;
	$othermetab = 0;
	$othermolec = 0;
	$plasma = 0;
	$plastid = 0;
	$protbind = 0;
	$protmet = 0;
	$recepbind = 0;
	$respabio = 0;
	$respstress = 0;
	$ribosome = 0;
	$signal = 0;
	$strucmol = 0;
	$transfac = 0;
	$transferase = 0;
	$transport = 0;
	$transporter = 0;
	$unkbiol = 0;
	$unkcell = 0;
	$unkmol = 0;


while (<IN1>) {
	chomp();
	push @array1, $_;
	@array1 = split/\t/;
	$length1 = $length1+1;
	if ($array1[1] =~ m/cell organization and biogenesis/) {$cellorgbio = $cellorgbio+1} 
	if ($array1[1] =~ m/cell wall/) {$cellwall = $cellwall+1} 
	if ($array1[1] =~ m/chloroplast/) {$chloroplast = $chloroplast+1}	
	if ($array1[1] =~ m/cytosol/) {$cytosol = $cytosol+1} 
	if ($array1[1] =~ m/developmental processes/) {$devproc = $devproc+1} 
	if ($array1[1] =~ m/DNA or RNA binding/) {$DNAbind = $DNAbind+1} 
	if ($array1[1] =~ m/DNA or RNA metabolism/) {$DNAmeta = $DNAmeta+1} 
	if ($array1[1] =~ m/electron transport or energy pathways/) {$electrans = $electrans+1} 
	if ($array1[1] =~ m/ER/) {$ER = $ER+1}
	if ($array1[1] =~ m/extracellular/) {$extracell = $extracell+1}
	if ($array1[1] =~ m/Golgi apparatus/) {$Golgi = $Golgi+1}
	if ($array1[1] =~ m/hydrolase activity/) {$hydrolase = $hydrolase+1}
	if ($array1[1] =~ m/kinase activity/) {$kinase = $kinase+1}
	if ($array1[1] =~ m/mitochondria/) {$mito = $mito+1}	
	if ($array1[1] =~ m/nucleic acid binding/) {$nucacbind = $nucacbind+1}
	if ($array1[1] =~ m/nucleotide binding/) {$nuctibind = $nuctibind+1}
	if ($array1[1] =~ m/nucleus/) {$nucleus = $nucleus+1}
	if ($array1[1] =~ m/other binding/) {$otherbind = $otherbind+1}
	if ($array1[1] =~ m/other biological processes/) {$otherbio = $otherbio+1}
	if ($array1[1] =~ m/other cellular components/) {$othercellcom = $othercellcom+1}
	if ($array1[1] =~ m/other cellular processes/) {$othercellproc = $othercellproc+1}
	if ($array1[1] =~ m/other cytoplasmic components/) {$othercyto = $othercyto+1}
	if ($array1[1] =~ m/other enzyme activity/) {$otherenzyme = $otherenzyme+1}
	if ($array1[1] =~ m/other intracellular components/) {$otherintra = $otherintra+1}
	if ($array1[1] =~ m/other membranes/) {$othermem = $othermem+1}
	if ($array1[1] =~ m/other metabolic processes/) {$othermetab = $othermetab+1}
	if ($array1[1] =~ m/other molecular functions/) {$othermolec = $othermolec+1}
	if ($array1[1] =~ m/plasma membrane/) {$plasma = $plasma+1}
	if ($array1[1] =~ m/plastid/) {$plastid = $plastid+1}
	if ($array1[1] =~ m/protein binding/) {$protbind = $protbind+1}
	if ($array1[1] =~ m/protein metabolism/) {$protmet = $protmet+1}
	if ($array1[1] =~ m/receptor binding or activity/) {$recepbind = $recepbind+1}
	if ($array1[1] =~ m/response to abiotic or biotic stimulus/) {$respabio = $respabio+1}
	if ($array1[1] =~ m/response to stress/) {$respstress = $respstress+1}
	if ($array1[1] =~ m/ribosome/) {$ribosome = $ribosome+1}
	if ($array1[1] =~ m/signal transduction/) {$signal = $signal+1}
	if ($array1[1] =~ m/structural molecule activity/) {$strucmol = $strucmol+1}
	if ($array1[1] =~ m/transcription factor activity/) {$transfac = $transfac+1}
	if ($array1[1] =~ m/transferase activity/) {$transferase = $transferase+1}
	if ($array1[1] =~ m/\Atransport\b/) {$transport = $transport+1}
	if ($array1[1] =~ m/transporter activity/) {$transporter = $transporter+1}
	if ($array1[1] =~ m/unknown biological processes/) {$unkbiol = $unkbiol+1}
	if ($array1[1] =~ m/unknown cellular components/) {$unkcell = $unkcell+1}
	if ($array1[1] =~ m/unknown molecular functions/) {$unkmol = $unkmol+1}
}	

	#print "The length of array1 is $length1\n"; 
	#print "The length of mito is $mito\n";
	#print "The length of ER is $ER\n";





open (OUT, ">rawTable_$file1");
print OUT "GO category, $file1\n";

@table = (
	['cell organization and biogenesis', $cellorgbio],
	['cell wall', $cellwall],
	['chloroplast', $chloroplast],	
	['cytosol', $cytosol],
	['developmental processes', $devproc],
	['DNA or RNA binding', $DNAbind],
	['DNA or RNA metabolism', $DNAmeta], 
	['electron transport or energy pathways', $electrans],
	['ER', $ER],
	['extracellular', $extracell],
	['Golgi apparatus', $Golgi],
	['hydrolase activity', $hydrolase],
	['kinase activity', $kinase],
	['mitochondria', $mito],
	['nucleic acid binding', $nucacbind],
	['nucleotide binding', $nuctibind],
	['nucleus', $nucleus],
	['other binding', $otherbind],
	['other biological processes', $otherbio],
	['other cellular components', $othercellcom],
	['other cellular processes', $othercellproc],
	['other cytoplasmic components', $othercyto],
	['other enzyme activity', $otherenzyme],
	['other intracellular components', $otherintra],
	['other membranes', $othermem],
	['other metabolic processes', $othermetab],
	['other molecular functions', $othermolec],
	['plasma membrane', $plasma],
	['plastid', $plastid],
	['protein binding', $protbind],
	['protein metabolism', $protmet],
	['receptor binding or activity', $recepbind],
	['response to abiotic or biotic stimulus', $respabio],
	['response to stress', $respstress],
	['ribosome', $ribosome],
	['signal transduction', $signal],
	['structural molecule activity', $strucmol],
	['transcription factor activity', $transfac],
	['transferase activity', $transferase],
	['transport', $transport],
	['transporter activity', $transporter],
	['unknown biological processes', $unkbiol],
	['unknown cellular components', $unkcell],
	['unknown molecular functions', $unkmol],
	);

for $row (@table) {
	my $join = join(',', @$row),;
	print OUT "$join\n";
	}

close(IN1);
close(OUT);





#my @table = (
#	['a', 'b', 'c'],
#	[1, 2, 3],
#	['gene', 'ks', 'annot'],
#	);

#for my $row (@table) {
#	my $join = join(',', @$row),;
#	print OUT "$join\n";
#	}

#close(OUT);