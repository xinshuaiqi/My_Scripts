#LD decay
setwd("C:/Users/qxs/Desktop/LD")

pdf("LD.pdf")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~all 145
df<-read.table(file="145.ld.10chr") 
head(df)
summary(df)

#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)

df2<-data.frame(df,bp)
head(df2)

#############
distance<-df2$bp
LD.data<-df2[,7]
n<-145      #number of individual
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

#par(new=T)
MMMM<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),xlab="",xlim=c(0,100000),ylab = "") #col=rgb(0,0,0,0,maxColorValue=255) xlim=c(0,100000),,xlim=c(0,100000) xlim=c(0,10000000),
NNNN<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,xlim=c(0,100000),col="black")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ol
df<-read.table(file="ol.ld.10chr")

head(df)
summary(df)
#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)


df2<-data.frame(df,bp)
head(df2)

#################################

distance<-df2$bp
LD.data<-df2[,7]
n<-13
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

par(new=T)
EEEE<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),
           xlab="",ylab = "",xlim=c(0,100000)) 
FFFF<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,col="blue",xlim=c(0,100000))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~rapa
df<-read.table(file="rapa.ld.10chr")

head(df)
summary(df)
#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)
#hist(bp,density=10,breaks=100)

df2<-data.frame(df,bp)
head(df2)

#################################

distance<-df2$bp
LD.data<-df2[,7]
n<-20
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

par(new=T)
GGGG<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),
           xlab="Distance (bp)",ylab = "r2",main ="10chr",xlim=c(0,100000)) #xlim=c(0,10000),col="white",xlim=c(0,100000)
HHHH<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,col="purple",xlim=c(0,100000))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sylv
df<-read.table(file="sylv.ld.10chr") 

head(df)
summary(df)
#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)
#hist(bp,density=10,breaks=100)

df2<-data.frame(df,bp)
head(df2)
#write.table(df2, "df2.2txt", sep="\t")

distance<-df2$bp
LD.data<-df2[,7]
  n<-7      #number of individual
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

par(new=T)
AAAA<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),xlab="",xlim=c(0,100000),ylab = "") #col=rgb(0,0,0,0,maxColorValue=255) xlim=c(0,100000),,xlim=c(0,100000) xlim=c(0,10000000),
BBBB<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,xlim=c(0,100000),col="orange")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~tril
df<-read.table(file="tril.ld.10chr")

head(df)
summary(df)
#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)
#hist(bp,density=10,breaks=100)


df2<-data.frame(df,bp)
head(df2)

distance<-df2$bp
LD.data<-df2[,7]
n<-20
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

par(new=T)
CCCC<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),
          xlab="",ylab = "",xlim=c(0,100000))
DDDD<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,col="green",xlim=c(0,100000))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~pk
#df<-read.table(file="sylv.ld.10chr") 

df<-read.table(file="pk.ld.10chr") 

head(df)
summary(df)
#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)
#hist(bp,density=10,breaks=100)

df2<-data.frame(df,bp)
head(df2)

distance<-df2$bp
LD.data<-df2[,7]
n<-28      #number of individual
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

par(new=T)
IIII<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),xlab="",xlim=c(0,100000),ylab = "") #col=rgb(0,0,0,0,maxColorValue=255) xlim=c(0,100000),,xlim=c(0,100000) xlim=c(0,10000000),
JJJJ<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,xlim=c(0,100000),col="yellow")


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ch
#df<-read.table(file="sylv.ld.10chr") 

df<-read.table(file="ch.ld.10chr") 

head(df)
summary(df)
#SNP distance , absolute value
bp <- abs(df[,2]-df[,5])
head(bp)
summary(bp)
max(bp)
length(bp)
#hist(bp,density=10,breaks=100)

df2<-data.frame(df,bp)
head(df2)

distance<-df2$bp
LD.data<-df2[,7]
n<-25      #number of individual
HW.st<-c(C=0.1)
HW.nonlinear<-nls(LD.data~((10+C*distance)/((2+C*distance)*(11+C*distance)))*(1+((3+C*distance)*(12+12*C*distance+(C*distance)^2))/(n*(2+C*distance)*(11+C*distance))),start=HW.st,control=nls.control(maxiter=100))
tt<-summary(HW.nonlinear)
new.rho<-tt$parameters[1]
fpoints<-((10+new.rho*distance)/((2+new.rho*distance)*(11+new.rho*distance)))*(1+((3+new.rho*distance)*(12+12*new.rho*distance+(new.rho*distance)^2))/(n*(2+new.rho*distance)*(11+new.rho*distance)))

LD.st<-c(b0=12.9)
distance.mb<-distance/1000000
LD.nonlinear<-nls(LD.data~(1-distance.mb)^b0,start=LD.st,control=nls.control(minFactor=1/1000000000,maxiter=100,warnOnly=T))
summ<-summary(LD.nonlinear)
param<-summ$parameters
beta0<-param["b0","Estimate"]
fpoints<-(1-distance.mb)^beta0

df<-data.frame(distance,fpoints)
maxld<-max(LD.data)
#You could eleucubrate if it's better to use the maximum ESTIMATED value of LD
#In that case you just set: maxld<-max(fpoints)
h.decay<-maxld/2
half.decay.distance<-df$distance[which.min(abs(df$fpoints-h.decay))]
half.decay.distance
ld.df<-data.frame(distance,fpoints)
ld.df<-ld.df[order(ld.df$distance),]

par(new=T)
KKKK<-plot(distance,LD.data,pch=19,cex=0.9,col=rgb(0,0,0,0,maxColorValue=255),xlab="",xlim=c(0,100000),ylab = "") #col=rgb(0,0,0,0,maxColorValue=255) xlim=c(0,100000),,xlim=c(0,100000) xlim=c(0,10000000),
LLLL<-lines(ld.df$distance,ld.df$fpoints,lty=3,lwd=3,xlim=c(0,100000),col="red")

dev.off()
#

#########################################################